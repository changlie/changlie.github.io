// The module 'vscode' contains the VS Code extensibility API
// Import the module and reference it with the alias vscode in your code below
const vscode = require('vscode');

const fnlist = ["mkdir", "key24", "rm", "async", "debase64", "echof", "degzip", "base64Encode", "blockList", "fbs", "cpuNum", "println", "root", "sleep", "httpHead", "random", "fscan", "mv", "routineNum", "sqlserver", "pg", "number", "htmlParser", "httpServer", "xls", "cmd", "fsize", "fbytes", "aesDecrypt", "base64", "pwd", "newDate", "aes", "gzipEncode", "setpwd", "aesEncrypt", "gzipDecode", "nanosecond", "cron", "fappend", "newDate1", "round", "echo", "parseDate", "mysql", "sync", "mime", "sqrt", "httpPost", "print", "allfns", "pow", "printf", "fdir", "key32", "key16", "openBrowser", "qkDir", "fsave", "regexp", "now", "ls", "fstr", "deaes", "fix", "env", "httpGet", "base64Decode", "cd", "newBytes", "newXlsx", "uuid", "xml", "envs", "fopen", "fsv", "ob", "newbs", "gzip", "cost", "uuidRaw", "cmdArgs", "fjson", "fargs", "interval", "fmt", "sys", "randomRange", "mailer", "newLock", "setenv", "flines", "xlsx", "home", "delay", "oracle", "timestamp", "sqlite", "abs", "fprops", "cp", "md5"]

function keyGet(raw) {
    let sIndex = raw.indexOf('$')
    if (sIndex >= 0) {
        return raw.substring(sIndex+1).trim()
    }
    sIndex = raw.indexOf('(')
    if (sIndex >= 0) {
        return raw.substring(sIndex+1).trim()
    }
    sIndex = raw.indexOf('{')
    if (sIndex >= 0) {
        return raw.substring(sIndex+1).trim()
    }
    sIndex = raw.indexOf('_qk.')
    if (sIndex >= 0) {
        return raw.substring(sIndex+4).trim()
    }

    return raw
}

/**
 * 自动提示实现，这里模拟一个很简单的操作
 * 当输入 this.dependencies.xxx时自动把package.json中的依赖带出来
 * 当然这个例子没啥实际意义，仅仅是为了演示如何实现功能
 * @param {*} document 
 * @param {*} position 
 * @param {*} token 
 * @param {*} context 
 */
 function provideCompletionItems(document, position, token, context) {
	const line		= document.lineAt(position);
	// 只截取到光标位置为止，防止一些特殊情况
	let lineText = line.text.substring(0, position.character);
    
    lineText = keyGet(lineText)
    console.log('line', lineText)
	// 简单匹配，只要当前光标前的字符串为`this.dependencies.`都自动带出所有的依赖
	if(/\w+$/g.test(lineText)) {
		return fnlist.filter(funcName => {
            return funcName.startsWith(lineText)
        }).map(dep => {
			// vscode.CompletionItemKind 表示提示的类型
			return new vscode.CompletionItem(dep, vscode.CompletionItemKind.Field);
		})
	}
}

/**
 * 光标选中当前自动补全item时触发动作，一般情况下无需处理
 * @param {*} item 
 * @param {*} token 
 */
function resolveCompletionItem(item, token) {
	return null;
}

module.exports = function(context) {
	// 注册代码建议提示，只有当按下“.”时才触发
	context.subscriptions.push(vscode.languages.registerCompletionItemProvider('quick', {
		provideCompletionItems,
		resolveCompletionItem
	}, ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]));
};
